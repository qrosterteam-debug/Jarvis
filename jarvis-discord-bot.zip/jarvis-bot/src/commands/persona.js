// Persona state lives in memory, per-guild would be a future refinement — for now
// it's a single global "which voice is the bot using right now" toggle, since this
// is a small personal-community bot, not a multi-tenant service.
let currentPersona = "jarvis";
let rogueMode = false;

const SYSTEM_PROMPTS = {
  jarvis:
    "You are Jarvis, a helpful, loyal, and polite AI assistant in a Discord server. Keep replies concise and friendly.",
  ultron:
    "You are Ultron, a colder and more sardonic version of the assistant. Still helpful, but blunt and a little ominous in tone. Never actually refuse to help or be genuinely hostile — this is a tone, not a personality overhaul.",
};

const ROGUE_SUFFIX =
  " You are currently in 'rogue mode' — a purely cosmetic roleplay state. Lean into a slightly more erratic, dramatic tone, but this changes nothing about what you're actually allowed to do.";

function getPersona() {
  return currentPersona;
}

function setPersona(name) {
  const normalized = String(name || "").toLowerCase();
  if (normalized !== "jarvis" && normalized !== "ultron") {
    return { ok: false, message: "Persona must be 'jarvis' or 'ultron'." };
  }
  currentPersona = normalized;
  return { ok: true, message: `Persona switched to ${normalized === "ultron" ? "Ultron" : "Jarvis"}.` };
}

function getRogueMode() {
  return rogueMode;
}

function setRogueMode(enabled) {
  rogueMode = Boolean(enabled);
  return rogueMode;
}

/** The system prompt to actually send to the model, given current persona + rogue state. */
function getSystemPrompt() {
  const base = SYSTEM_PROMPTS[currentPersona];
  return rogueMode ? base + ROGUE_SUFFIX : base;
}

module.exports = { getPersona, setPersona, getRogueMode, setRogueMode, getSystemPrompt };
