const { Client, GatewayIntentBits, Partials } = require("discord.js");
const { DISCORD_BOT_TOKEN, OWNER_ID } = require("./src/config");
const { handleMessage } = require("./src/messageHandler");

if (!DISCORD_BOT_TOKEN) {
  console.error("DISCORD_BOT_TOKEN is not set — check your .env file.");
  process.exit(1);
}
if (!OWNER_ID) {
  console.warn("WARNING: OWNER_DISCORD_ID is not set — the Owner-immunity rule has no effect until it is.");
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Message, Partials.Channel],
});

client.once("ready", () => {
  console.log(`Jarvis is online as ${client.user.tag}`);
});

client.on("messageCreate", (message) => {
  handleMessage(message, client).catch((err) => {
    console.error("Error handling message:", err);
    message.reply("Something went wrong handling that — check the server logs.").catch(() => {});
  });
});

client.on("error", (err) => {
  console.error("Discord client error:", err);
});

client.login(DISCORD_BOT_TOKEN);
