const { COMMAND_CLEARANCE, OWNER_ID } = require("./config");

/** True if a user's level meets a command's minimum requirement. */
function meetsRequirement(userLevel, commandName) {
  const entry = COMMAND_CLEARANCE[commandName];
  if (!entry) {
    throw new Error(`Unknown command in permission table: ${commandName}`);
  }
  return userLevel >= entry.level;
}

/**
 * Decides whether `actor` is allowed to change `target`'s clearance level.
 * Returns { allowed: boolean, reason: string|null } — reason is set only when denied,
 * so callers can relay a clear explanation back to the user.
 *
 * Rules, in order:
 *  1. Nobody can change the Owner's clearance — not even the Owner, via this path.
 *  2. The Owner can change anyone else's clearance, at any level, including a level-7
 *     Architect down to level 6 or below.
 *  3. Otherwise: actor's level must be STRICTLY GREATER than target's level. Equal or
 *     lower is always denied, with no exceptions beyond the Owner rule above.
 */
function canChangeClearance({ actorId, actorLevel, targetId, targetLevel }) {
  if (OWNER_ID && targetId === OWNER_ID) {
    return { allowed: false, reason: "The Owner's clearance cannot be changed." };
  }
  if (OWNER_ID && actorId === OWNER_ID) {
    return { allowed: true, reason: null };
  }
  if (actorLevel > targetLevel) {
    return { allowed: true, reason: null };
  }
  return {
    allowed: false,
    reason: "You cannot change the clearance of someone at an equal or higher level than you.",
  };
}

/** True if `userId` is the hardcoded Owner. */
function isOwner(userId) {
  return Boolean(OWNER_ID) && userId === OWNER_ID;
}

module.exports = { meetsRequirement, canChangeClearance, isOwner };
