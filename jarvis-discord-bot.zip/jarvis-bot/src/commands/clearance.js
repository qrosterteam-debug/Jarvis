const { CLEARANCE_NAMES, MAX_LEVEL, MIN_LEVEL } = require("../config");
const { canChangeClearance } = require("../permissions");
const {
  getClearance,
  setClearance,
  revokeClearance,
  listUsersAtOrAbove,
  getClearanceHistory,
} = require("../db");

function levelName(level) {
  return CLEARANCE_NAMES[level] || `Level ${level}`;
}

function checkOwnClearance(userId) {
  const level = getClearance(userId);
  return `You are clearance level ${level} (${levelName(level)}).`;
}

function checkOtherClearance(targetId, targetTag) {
  const level = getClearance(targetId);
  return `${targetTag} is clearance level ${level} (${levelName(level)}).`;
}

/** `clearance list` — masks levels 6-7 unless the asker is level 7. */
function clearanceList(askerLevel) {
  const maxShown = askerLevel >= 7 ? MAX_LEVEL : 5;
  const lines = [];
  for (let lvl = MIN_LEVEL; lvl <= maxShown; lvl++) {
    lines.push(`Level ${lvl} — ${levelName(lvl)}`);
  }
  return lines.join("\n");
}

/** Attempts to set a user's clearance, enforcing the equal-or-higher + Owner rules. */
function trySetClearance({ actorId, actorLevel, targetId, targetTag, newLevel }) {
  if (newLevel < MIN_LEVEL || newLevel > MAX_LEVEL) {
    return { ok: false, message: `Level must be between ${MIN_LEVEL} and ${MAX_LEVEL}.` };
  }
  const targetLevel = getClearance(targetId);
  const decision = canChangeClearance({ actorId, actorLevel, targetId, targetLevel });
  if (!decision.allowed) {
    return { ok: false, message: decision.reason };
  }
  const { oldLevel } = setClearance(actorId, targetId, newLevel);
  return {
    ok: true,
    message: `${targetTag}'s clearance changed from ${oldLevel} (${levelName(oldLevel)}) to ${newLevel} (${levelName(newLevel)}).`,
  };
}

function tryRevokeClearance({ actorId, actorLevel, targetId, targetTag }) {
  const targetLevel = getClearance(targetId);
  const decision = canChangeClearance({ actorId, actorLevel, targetId, targetLevel });
  if (!decision.allowed) {
    return { ok: false, message: decision.reason };
  }
  revokeClearance(actorId, targetId);
  return { ok: true, message: `${targetTag}'s stored clearance was revoked (reset to level 1).` };
}

function listAtOrAbove(minLevel) {
  const rows = listUsersAtOrAbove(minLevel);
  if (rows.length === 0) return `No users found at level ${minLevel}+.`;
  return rows.map((r) => `<@${r.user_id}> — level ${r.level} (${levelName(r.level)})`).join("\n");
}

function historyAll() {
  const rows = getClearanceHistory({ limit: 25 });
  if (rows.length === 0) return "No clearance changes recorded yet.";
  return rows
    .map(
      (r) =>
        `<@${r.actor_id}> set <@${r.target_id}> from ${r.old_level ?? "—"} to ${r.new_level} (${r.created_at})`
    )
    .join("\n");
}

function historyForUser(targetId, targetTag) {
  const rows = getClearanceHistory({ targetId, limit: 25 });
  if (rows.length === 0) return `No clearance history for ${targetTag}.`;
  return rows
    .map((r) => `<@${r.actor_id}> set them from ${r.old_level ?? "—"} to ${r.new_level} (${r.created_at})`)
    .join("\n");
}

module.exports = {
  levelName,
  checkOwnClearance,
  checkOtherClearance,
  clearanceList,
  trySetClearance,
  tryRevokeClearance,
  listAtOrAbove,
  historyAll,
  historyForUser,
};
