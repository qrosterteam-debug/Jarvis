const { chat } = require("./ollama");

// Every recognized command the parser is allowed to output. Kept in sync with
// config.js's COMMAND_CLEARANCE table by convention — see the note in config.js.
const KNOWN_COMMANDS = [
  "whoami",
  "help",
  "clear_memory",
  "check_own_clearance",
  "check_other_clearance",
  "clearance_list",
  "set_clearance",
  "revoke_clearance",
  "clearance_history_all",
  "clearance_history_user",
  "list_files",
  "read_file",
  "search_files",
  "create_file",
  "edit_file",
  "delete_file",
  "modules_status",
  "terminate_module",
  "restore_module",
  "switch_persona",
  "chat", // fallback: not a command, just ordinary conversation
];

const SYSTEM_PROMPT = `You turn a Discord message into a single structured command for a bot called Jarvis.

Respond with ONLY a JSON object, no other text, matching this shape exactly:
{
  "command": one of ${JSON.stringify(KNOWN_COMMANDS)},
  "level": integer or null (a clearance level number, 1-7, if mentioned),
  "filename": string or null (a file name, if mentioned),
  "content": string or null (file content to write, if this is a create/edit request),
  "module_name": string or null (a module name, if mentioned),
  "query": string or null (a search topic, if this is a search request),
  "persona": "jarvis" or "ultron" or null (if this is a persona-switch request)
}

Notes:
- Do NOT try to identify *who* a command targets — that is handled separately from your output. Focus only on WHAT the person wants to do.
- If the message doesn't match any real command, use "command": "chat" — this covers ordinary conversation, questions, or anything else. When in doubt, prefer "chat".
- Never invent a command name outside the provided list.
- Output raw JSON only — no markdown fences, no explanation.`;

/**
 * Parses a Discord message's text into a structured intent.
 * Returns a safe default ({ command: "chat", ...nulls }) if parsing fails for any
 * reason — a failed parse should always fall through to ordinary conversation, never
 * throw or silently perform an unintended action.
 */
async function parseIntent(messageText) {
  const fallback = {
    command: "chat",
    level: null,
    filename: null,
    content: null,
    module_name: null,
    query: null,
    persona: null,
  };

  try {
    const raw = await chat(
      [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: messageText },
      ],
      { format: "json" }
    );

    const parsed = JSON.parse(raw);
    if (!KNOWN_COMMANDS.includes(parsed.command)) {
      return fallback;
    }
    return { ...fallback, ...parsed };
  } catch (err) {
    return fallback;
  }
}

module.exports = { parseIntent, KNOWN_COMMANDS };
