const { COMMAND_CLEARANCE } = require("../config");
const { getClearance, clearConversationHistory } = require("../db");
const { levelName } = require("./clearance");
const { isOwner } = require("../permissions");

function whoami(userId, userTag) {
  const level = getClearance(userId);
  const ownerNote = isOwner(userId) ? " (Owner)" : "";
  return `${userTag}\nClearance: ${level} (${levelName(level)})${ownerNote}`;
}

/** Generates .help text directly from COMMAND_CLEARANCE — the same table that enforces
 * permissions — so this can never drift out of sync with what's actually allowed. */
function help() {
  const lines = ["**Jarvis — Command Guide**", ""];
  const sorted = Object.entries(COMMAND_CLEARANCE).sort((a, b) => a[1].level - b[1].level);
  for (const [name, { level, description }] of sorted) {
    lines.push(`• \`${name}\` (level ${level}+) — ${description}`);
  }
  return lines.join("\n");
}

function clearMemory(userId) {
  clearConversationHistory(userId);
  return "Your conversation history with me has been cleared.";
}

module.exports = { whoami, help, clearMemory };
