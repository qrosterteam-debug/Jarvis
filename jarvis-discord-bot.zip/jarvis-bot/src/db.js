const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");
const { DEFAULT_LEVEL } = require("./config");

const DATA_DIR = path.join(__dirname, "..", "data");
fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new Database(path.join(DATA_DIR, "jarvis.db"));
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS clearance (
    user_id TEXT PRIMARY KEY,
    level INTEGER NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS clearance_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    actor_id TEXT NOT NULL,
    target_id TEXT NOT NULL,
    old_level INTEGER,
    new_level INTEGER NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS file_manifest (
    filename TEXT PRIMARY KEY,
    min_clearance INTEGER NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS module_status (
    name TEXT PRIMARY KEY,
    online INTEGER NOT NULL DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS conversation_history (
    user_id TEXT PRIMARY KEY,
    history_json TEXT NOT NULL DEFAULT '[]',
    updated_at TEXT NOT NULL
  );
`);

/** ISO 8601 timestamp, set explicitly from JS on every write instead of relying on a
 * SQL-level DEFAULT — some SQLite builds reject datetime('now') as a column default. */
function now() {
  return new Date().toISOString();
}

// ——— Clearance ———
function getClearance(userId) {
  const row = db.prepare("SELECT level FROM clearance WHERE user_id = ?").get(userId);
  return row ? row.level : DEFAULT_LEVEL;
}

function setClearance(actorId, targetId, newLevel) {
  const oldLevel = getClearance(targetId);
  db.prepare(
    `INSERT INTO clearance (user_id, level, updated_at) VALUES (?, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET level = excluded.level, updated_at = excluded.updated_at`
  ).run(targetId, newLevel, now());
  db.prepare(
    "INSERT INTO clearance_history (actor_id, target_id, old_level, new_level, created_at) VALUES (?, ?, ?, ?, ?)"
  ).run(actorId, targetId, oldLevel, newLevel, now());
  return { oldLevel, newLevel };
}

function revokeClearance(actorId, targetId) {
  const oldLevel = getClearance(targetId);
  db.prepare("DELETE FROM clearance WHERE user_id = ?").run(targetId);
  db.prepare(
    "INSERT INTO clearance_history (actor_id, target_id, old_level, new_level, created_at) VALUES (?, ?, ?, ?, ?)"
  ).run(actorId, targetId, oldLevel, DEFAULT_LEVEL, now());
  return { oldLevel };
}

function listUsersAtOrAbove(minLevel) {
  return db.prepare("SELECT user_id, level FROM clearance WHERE level >= ? ORDER BY level DESC").all(minLevel);
}

function getClearanceHistory({ targetId = null, limit = 25 } = {}) {
  if (targetId) {
    return db
      .prepare("SELECT * FROM clearance_history WHERE target_id = ? ORDER BY created_at DESC LIMIT ?")
      .all(targetId, limit);
  }
  return db.prepare("SELECT * FROM clearance_history ORDER BY created_at DESC LIMIT ?").all(limit);
}

// ——— File manifest ———
function setFileClearance(filename, minClearance, createdBy) {
  db.prepare(
    `INSERT INTO file_manifest (filename, min_clearance, created_by, created_at) VALUES (?, ?, ?, ?)
     ON CONFLICT(filename) DO UPDATE SET min_clearance = excluded.min_clearance`
  ).run(filename, minClearance, createdBy, now());
}

function getFileClearance(filename) {
  const row = db.prepare("SELECT min_clearance FROM file_manifest WHERE filename = ?").get(filename);
  return row ? row.min_clearance : null;
}

function listFilesAtOrBelow(userLevel) {
  return db
    .prepare("SELECT filename, min_clearance FROM file_manifest WHERE min_clearance <= ? ORDER BY filename")
    .all(userLevel);
}

function deleteFileRecord(filename) {
  db.prepare("DELETE FROM file_manifest WHERE filename = ?").run(filename);
}

// ——— Modules ———
function isModuleOnline(name) {
  const row = db.prepare("SELECT online FROM module_status WHERE name = ?").get(name);
  return row ? Boolean(row.online) : true; // default online if never toggled
}

function setModuleStatus(name, online) {
  db.prepare(
    `INSERT INTO module_status (name, online) VALUES (?, ?)
     ON CONFLICT(name) DO UPDATE SET online = excluded.online`
  ).run(name, online ? 1 : 0);
}

function listModules(knownModuleNames) {
  return knownModuleNames.map((name) => ({ name, online: isModuleOnline(name) }));
}

// ——— Conversation history (per-user, for "clear my memory") ———
function getConversationHistory(userId) {
  const row = db.prepare("SELECT history_json FROM conversation_history WHERE user_id = ?").get(userId);
  return row ? JSON.parse(row.history_json) : [];
}

function saveConversationHistory(userId, historyArray) {
  const json = JSON.stringify(historyArray);
  db.prepare(
    `INSERT INTO conversation_history (user_id, history_json, updated_at) VALUES (?, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET history_json = excluded.history_json, updated_at = excluded.updated_at`
  ).run(userId, json, now());
}

function clearConversationHistory(userId) {
  db.prepare("DELETE FROM conversation_history WHERE user_id = ?").run(userId);
}

module.exports = {
  db,
  getClearance,
  setClearance,
  revokeClearance,
  listUsersAtOrAbove,
  getClearanceHistory,
  setFileClearance,
  getFileClearance,
  listFilesAtOrBelow,
  deleteFileRecord,
  isModuleOnline,
  setModuleStatus,
  listModules,
  getConversationHistory,
  saveConversationHistory,
  clearConversationHistory,
};
