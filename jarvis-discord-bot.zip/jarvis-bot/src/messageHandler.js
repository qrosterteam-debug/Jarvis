const { meetsRequirement } = require("./permissions");
const { getClearance, getConversationHistory, saveConversationHistory } = require("./db");
const { parseIntent } = require("./intentParser");
const { chat } = require("./ollama");
const clearanceCmds = require("./commands/clearance");
const filesCmds = require("./commands/files");
const modulesCmds = require("./commands/modules");
const miscCmds = require("./commands/misc");
const persona = require("./commands/persona");

const NEEDS_TARGET = ["check_other_clearance", "set_clearance", "revoke_clearance", "clearance_history_user"];

function checkPerm(userLevel, cmd) {
  try {
    return meetsRequirement(userLevel, cmd);
  } catch {
    return false;
  }
}

function denyMessage(userLevel) {
  return `That requires higher clearance than you currently have (you are level ${userLevel}).`;
}

async function ordinaryChat(userId, text) {
  if (!modulesCmds.isOnline("personality")) {
    return "The personality module is currently terminated — I can't chat normally right now.";
  }
  const history = getConversationHistory(userId);
  const messages = [
    { role: "system", content: persona.getSystemPrompt() },
    ...history,
    { role: "user", content: text },
  ];
  const reply = await chat(messages);
  const newHistory = [...history, { role: "user", content: text }, { role: "assistant", content: reply }].slice(-20);
  saveConversationHistory(userId, newHistory);
  return reply;
}

/**
 * Executes one parsed intent. This is the ONLY place commands actually run — every
 * branch checks the permission table before doing anything with real effect. The model
 * (via `intent`) only ever supplied WHAT was asked for; this function alone decides
 * WHETHER it's allowed.
 */
async function dispatch({ intent, userId, userTag, userLevel, targetId, targetTag, cleanedText }) {
  const cmd = intent.command;

  if (NEEDS_TARGET.includes(cmd) && !targetId) {
    return "You need to mention a user for that command.";
  }

  switch (cmd) {
    case "whoami":
      return miscCmds.whoami(userId, userTag);

    case "help":
      return miscCmds.help();

    case "clear_memory":
      return miscCmds.clearMemory(userId);

    case "check_own_clearance":
      return clearanceCmds.checkOwnClearance(userId);

    case "check_other_clearance":
      if (!checkPerm(userLevel, "check_other_clearance")) return denyMessage(userLevel);
      return clearanceCmds.checkOtherClearance(targetId, targetTag);

    case "clearance_list":
      return clearanceCmds.clearanceList(userLevel);

    case "set_clearance": {
      if (!checkPerm(userLevel, "set_clearance")) return denyMessage(userLevel);
      if (!modulesCmds.isOnline("clearance")) return "The clearance module is currently terminated.";
      if (intent.level === null) return "Please specify a clearance level.";
      const result = clearanceCmds.trySetClearance({
        actorId: userId,
        actorLevel: userLevel,
        targetId,
        targetTag,
        newLevel: intent.level,
      });
      return result.message;
    }

    case "revoke_clearance": {
      if (!checkPerm(userLevel, "revoke_clearance")) return denyMessage(userLevel);
      if (!modulesCmds.isOnline("clearance")) return "The clearance module is currently terminated.";
      const result = clearanceCmds.tryRevokeClearance({ actorId: userId, actorLevel: userLevel, targetId, targetTag });
      return result.message;
    }

    case "clearance_history_all":
      if (!checkPerm(userLevel, "clearance_history_all")) return denyMessage(userLevel);
      return clearanceCmds.historyAll();

    case "clearance_history_user":
      if (!checkPerm(userLevel, "clearance_history_user")) return denyMessage(userLevel);
      return clearanceCmds.historyForUser(targetId, targetTag);

    case "list_files": {
      if (!modulesCmds.isOnline("files")) return "The files module is currently terminated.";
      const rows = filesCmds.listFiles(userLevel);
      return rows.length ? rows.map((r) => `${r.filename} (level ${r.min_clearance}+)`).join("\n") : "No files accessible to you.";
    }

    case "read_file": {
      if (!modulesCmds.isOnline("files")) return "The files module is currently terminated.";
      if (!intent.filename) return "Please specify a filename.";
      const result = filesCmds.readFile(intent.filename, userLevel);
      return result.ok ? "```\n" + result.content.slice(0, 1500) + "\n```" : result.error;
    }

    case "search_files": {
      if (!modulesCmds.isOnline("files")) return "The files module is currently terminated.";
      if (!intent.query) return "Please specify a search topic.";
      const matches = filesCmds.searchFiles(intent.query, userLevel);
      return matches.length ? matches.join("\n") : "No matching files found.";
    }

    case "create_file": {
      if (!checkPerm(userLevel, "create_file")) return denyMessage(userLevel);
      if (!modulesCmds.isOnline("files")) return "The files module is currently terminated.";
      if (!intent.filename) return "Please specify a filename.";
      const result = filesCmds.createFile(intent.filename, intent.level || 1, intent.content || "", userId, userLevel);
      return result.ok ? `File "${intent.filename}" created at clearance level ${intent.level || 1}.` : result.error;
    }

    case "edit_file": {
      if (!checkPerm(userLevel, "edit_file")) return denyMessage(userLevel);
      if (!modulesCmds.isOnline("files")) return "The files module is currently terminated.";
      if (!intent.filename) return "Please specify a filename.";
      const result = filesCmds.editFile(intent.filename, intent.content || "", userLevel);
      return result.ok ? `File "${intent.filename}" updated.` : result.error;
    }

    case "delete_file": {
      if (!checkPerm(userLevel, "delete_file")) return denyMessage(userLevel);
      if (!modulesCmds.isOnline("files")) return "The files module is currently terminated.";
      if (!intent.filename) return "Please specify a filename.";
      const result = filesCmds.deleteFile(intent.filename, userLevel);
      return result.ok ? `File "${intent.filename}" deleted.` : result.error;
    }

    case "modules_status":
      if (!checkPerm(userLevel, "modules_status")) return denyMessage(userLevel);
      return modulesCmds.status();

    case "terminate_module": {
      if (!checkPerm(userLevel, "terminate_module")) return denyMessage(userLevel);
      if (!intent.module_name) return "Please specify a module name.";
      return modulesCmds.terminate(intent.module_name).message;
    }

    case "restore_module": {
      if (!checkPerm(userLevel, "restore_module")) return denyMessage(userLevel);
      if (!intent.module_name) return "Please specify a module name.";
      return modulesCmds.restore(intent.module_name).message;
    }

    case "switch_persona": {
      if (!checkPerm(userLevel, "switch_persona")) return denyMessage(userLevel);
      if (!modulesCmds.isOnline("personality")) return "The personality module is currently terminated.";
      if (!intent.persona) return "Please specify 'jarvis' or 'ultron'.";
      return persona.setPersona(intent.persona).message;
    }

    case "chat":
    default:
      return ordinaryChat(userId, cleanedText);
  }
}

async function isReplyToBotMessage(message, client) {
  if (!message.reference) return false;
  try {
    const referenced = await message.fetchReference();
    return referenced.author.id === client.user.id;
  } catch {
    return false;
  }
}

/** Entry point wired to Discord.js's messageCreate event. */
async function handleMessage(message, client) {
  if (message.author.bot) return;

  const isMentioned = message.mentions.has(client.user);
  const isReply = await isReplyToBotMessage(message, client);
  if (!isMentioned && !isReply) return;

  const userId = message.author.id;
  const userTag = `<@${userId}>`;
  const userLevel = getClearance(userId);

  const cleanedText = message.content.replace(new RegExp(`<@!?${client.user.id}>`, "g"), "").trim();

  const targetUser = message.mentions.users.filter((u) => u.id !== client.user.id).first();
  const targetId = targetUser ? targetUser.id : null;
  const targetTag = targetId ? `<@${targetId}>` : null;

  const intent = await parseIntent(cleanedText);

  const reply = await dispatch({ intent, userId, userTag, userLevel, targetId, targetTag, cleanedText });

  if (reply) {
    await message.reply(String(reply).slice(0, 2000)); // Discord's hard message-length cap
  }
}

module.exports = { handleMessage, dispatch };
