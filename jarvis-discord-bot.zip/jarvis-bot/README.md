# Jarvis Discord Bot

## What's built
- Clearance system (7 levels, Owner immunity, equal-or-higher protection) — `src/permissions.js`, `src/commands/clearance.js`
- Flexible natural-language commands — the model parses intent only (`src/intentParser.js`); all permission checks and actual execution happen in code (`src/messageHandler.js`), never the model
- Files scoped to a workspace directory with per-file clearance tags — `src/commands/files.js`
- Toggleable modules (clearance, files, personality) — `src/commands/modules.js`
- Persona/tone switching + cosmetic rogue mode — `src/commands/persona.js`
- SQLite storage — `src/db.js`

Every safety-critical piece (permission logic, path-traversal protection, the dispatch
table, intent-parser fallback behavior) was functionally tested during the build, not
just syntax-checked. What's genuinely untested: an actual live Discord connection and
a real Ollama API call — no network access was available to run those live.

## Deploying to your Azure VM

1. **Get the code onto the VM.** Since there's no public IP, use the Serial Console to
   set up SSH access temporarily (attach a public IP just long enough to `scp` this
   folder over, or use `git` if you push this to a private repo), or paste files in
   directly via Serial Console for smaller edits.

2. **Install Node.js** on the VM (Ubuntu 24.04):
   ```
   curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```

3. **Install dependencies:**
   ```
   cd jarvis-bot
   npm install
   ```
   This is the first real test of `better-sqlite3` (a native module) and `discord.js` —
   watch for errors here, they're the most likely first bump.

4. **Set up your `.env` file:**
   ```
   cp .env.example .env
   nano .env
   ```
   Fill in `DISCORD_BOT_TOKEN`, `OWNER_DISCORD_ID` (your own Discord user ID), and
   `OLLAMA_API_KEY`.

5. **Run it:**
   ```
   node index.js
   ```
   You should see `Jarvis is online as <botname>#0000` — that confirms the Discord
   connection worked. Then try mentioning it in your server.

6. **Keep it running after you disconnect** — use `pm2` (a process manager) so the bot
   survives you closing the SSH/Serial Console session:
   ```
   sudo npm install -g pm2
   pm2 start index.js --name jarvis-bot
   pm2 save
   ```

## Known gaps / next steps
- Only one command per message is currently recognized — chaining ("set clearance AND
  show me the list") isn't supported. Worth adding if it comes up.
- Conversation history caps at the last 20 messages per user, to keep prompts from
  growing unbounded — not configurable yet.
- No per-guild persona state — if this bot is ever added to more than one server,
  persona/rogue mode is currently global, not per-server. Fine for a single-server bot.
- Module levels (clearance 6+ for `.terminate`/`.restore`) were a reasonable default,
  not something you explicitly specified — flagged in `src/config.js` too, adjust if
  you want a different threshold.

## If something breaks
Paste the actual error output here — this was built and tested directly, so it can be
debugged directly too.
