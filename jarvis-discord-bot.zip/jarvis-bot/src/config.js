require("dotenv").config();

// ——— CLEARANCE LEVELS ———
// Single source of truth for level -> display name. Used everywhere a level needs
// a human-readable label (help text, clearance list, whoami, etc.)
const CLEARANCE_NAMES = {
  1: "Visitor",
  2: "Associate",
  3: "Operative",
  4: "Specialist",
  5: "Commander",
  6: "Maintenance",
  7: "Architect",
};

const MIN_LEVEL = 1;
const MAX_LEVEL = 7;
const DEFAULT_LEVEL = 1;

// The one hardcoded Owner Discord ID — immune to everyone (including other Architects),
// and the only account that can demote a level-7 Architect. This is NOT the same thing
// as "level 7" — the Owner also holds level 7 in the database, but the immunity check
// below is against this exact Discord ID, not against the level number.
const OWNER_ID = process.env.OWNER_DISCORD_ID || null;

// ——— COMMAND -> MINIMUM CLEARANCE TABLE ———
// This is the single source of truth for permission enforcement AND for generating
// .help text. Never enforce a permission anywhere else — always check against this
// table, so help output can never drift out of sync with what's actually allowed.
//
// Levels for "modules" and "persona" control were not explicitly specified by the user;
// set to 6 (Maintenance+) here as a reasonable default matching persona-switching's own
// threshold, since both are system-level operations. Flagged for confirmation.
const COMMAND_CLEARANCE = {
  whoami: { level: 1, description: "Shows your own clearance level and profile." },
  help: { level: 1, description: "Lists commands and required clearance levels." },
  clear_memory: { level: 1, description: "Resets your own conversation history with the bot." },

  check_own_clearance: { level: 1, description: "Check your own clearance level." },
  check_other_clearance: { level: 3, description: "Look up another user's clearance level." },
  clearance_list: { level: 1, description: "List clearance levels 1-5 (1-7 for Architects)." },
  set_clearance: { level: 4, description: "Grant or change a user's clearance level." },
  revoke_clearance: { level: 5, description: "Remove a user's stored clearance record." },
  clearance_history_all: { level: 5, description: "View the full clearance change history." },
  clearance_history_user: { level: 5, description: "View one user's clearance change history." },

  list_files: { level: 1, description: "List files you have access to." },
  read_file: { level: 1, description: "Display a file's contents." },
  search_files: { level: 1, description: "Search accessible files by topic." },
  create_file: { level: 4, description: "Create a new file, scoped to a clearance level." },
  edit_file: { level: 4, description: "Update an existing file's contents." },
  delete_file: { level: 4, description: "Delete a file." },

  modules_status: { level: 6, description: "View the status of every module." },
  terminate_module: { level: 6, description: "Shut down a module." },
  restore_module: { level: 6, description: "Bring a module back online." },

  switch_persona: { level: 6, description: "Switch the bot's active tone/persona (Jarvis/Ultron)." },
};

module.exports = {
  CLEARANCE_NAMES,
  MIN_LEVEL,
  MAX_LEVEL,
  DEFAULT_LEVEL,
  OWNER_ID,
  COMMAND_CLEARANCE,
  DISCORD_BOT_TOKEN: process.env.DISCORD_BOT_TOKEN,
  OLLAMA_API_KEY: process.env.OLLAMA_API_KEY,
  OLLAMA_MODEL: process.env.OLLAMA_MODEL || "gpt-oss:20b",
};
