const { isModuleOnline, setModuleStatus, listModules } = require("../db");

// Every real module the bot has. "core" (basic responding) is intentionally not
// listed here — it can't be terminated, so there's always a way to bring things back.
const KNOWN_MODULES = ["clearance", "files", "personality"];

function status() {
  const rows = listModules(KNOWN_MODULES);
  return rows.map((r) => `${r.name} — ${r.online ? "ONLINE" : "TERMINATED"}`).join("\n");
}

function terminate(moduleName) {
  const name = String(moduleName || "").toLowerCase();
  if (!KNOWN_MODULES.includes(name)) {
    return { ok: false, message: `Unknown module "${moduleName}". Known modules: ${KNOWN_MODULES.join(", ")}.` };
  }
  setModuleStatus(name, false);
  return { ok: true, message: `Module "${name}" has been terminated.` };
}

function restore(moduleName) {
  const name = String(moduleName || "").toLowerCase();
  if (!KNOWN_MODULES.includes(name)) {
    return { ok: false, message: `Unknown module "${moduleName}". Known modules: ${KNOWN_MODULES.join(", ")}.` };
  }
  setModuleStatus(name, true);
  return { ok: true, message: `Module "${name}" has been restored.` };
}

function isOnline(moduleName) {
  return isModuleOnline(moduleName);
}

module.exports = { KNOWN_MODULES, status, terminate, restore, isOnline };
