const fs = require("fs");
const path = require("path");
const {
  setFileClearance,
  getFileClearance,
  listFilesAtOrBelow,
  deleteFileRecord,
} = require("../db");

const WORKSPACE_DIR = path.join(__dirname, "..", "..", "workspace");
fs.mkdirSync(WORKSPACE_DIR, { recursive: true });

/** Resolves a filename inside WORKSPACE_DIR only. Throws if it would escape it —
 * same path-traversal guard used in the jarvis.py version. */
function safeWorkspacePath(filename) {
  const cleaned = String(filename || "").replace(/^\/+/, "");
  const target = path.resolve(WORKSPACE_DIR, cleaned);
  const base = path.resolve(WORKSPACE_DIR);
  if (target !== base && !target.startsWith(base + path.sep)) {
    throw new Error("Path escapes the workspace.");
  }
  return target;
}

function listFiles(userLevel) {
  return listFilesAtOrBelow(userLevel);
}

function readFile(filename, userLevel) {
  const minClearance = getFileClearance(filename);
  if (minClearance === null) {
    return { ok: false, error: "File not found." };
  }
  if (userLevel < minClearance) {
    return { ok: false, error: "Your clearance is too low to read this file." };
  }
  const target = safeWorkspacePath(filename);
  if (!fs.existsSync(target)) {
    return { ok: false, error: "File not found on disk (manifest is out of sync)." };
  }
  const content = fs.readFileSync(target, "utf8");
  return { ok: true, content };
}

function createFile(filename, level, content, createdBy, userLevel) {
  if (userLevel < 4) {
    return { ok: false, error: "Level 4+ is required to create files." };
  }
  if (getFileClearance(filename) !== null) {
    return { ok: false, error: "A file with that name already exists." };
  }
  const target = safeWorkspacePath(filename);
  fs.writeFileSync(target, content || "");
  setFileClearance(filename, level || 1, createdBy);
  return { ok: true };
}

function editFile(filename, content, userLevel) {
  if (userLevel < 4) {
    return { ok: false, error: "Level 4+ is required to edit files." };
  }
  const minClearance = getFileClearance(filename);
  if (minClearance === null) {
    return { ok: false, error: "File not found." };
  }
  const target = safeWorkspacePath(filename);
  fs.writeFileSync(target, content || "");
  return { ok: true };
}

function deleteFile(filename, userLevel) {
  if (userLevel < 4) {
    return { ok: false, error: "Level 4+ is required to delete files." };
  }
  const minClearance = getFileClearance(filename);
  if (minClearance === null) {
    return { ok: false, error: "File not found." };
  }
  const target = safeWorkspacePath(filename);
  if (fs.existsSync(target)) fs.unlinkSync(target);
  deleteFileRecord(filename);
  return { ok: true };
}

function searchFiles(query, userLevel) {
  const accessible = listFilesAtOrBelow(userLevel);
  const lowerQuery = String(query || "").toLowerCase();
  const matches = [];
  for (const { filename } of accessible) {
    try {
      const target = safeWorkspacePath(filename);
      if (!fs.existsSync(target)) continue;
      const content = fs.readFileSync(target, "utf8");
      if (filename.toLowerCase().includes(lowerQuery) || content.toLowerCase().includes(lowerQuery)) {
        matches.push(filename);
      }
    } catch {
      continue;
    }
  }
  return matches;
}

module.exports = {
  WORKSPACE_DIR,
  safeWorkspacePath,
  listFiles,
  readFile,
  createFile,
  editFile,
  deleteFile,
  searchFiles,
};
