const { OLLAMA_API_KEY, OLLAMA_MODEL } = require("./config");

const OLLAMA_CHAT_URL = "https://ollama.com/api/chat";

/**
 * Sends a chat completion request to Ollama's cloud API.
 * messages: [{ role: "system"|"user"|"assistant", content: string }]
 * Returns the assistant's reply text (string).
 */
async function chat(messages, { model = OLLAMA_MODEL, format = null } = {}) {
  if (!OLLAMA_API_KEY) {
    throw new Error("OLLAMA_API_KEY is not set — check your .env file.");
  }

  const body = { model, messages, stream: false };
  if (format) body.format = format; // e.g. "json" to force structured output

  const response = await fetch(OLLAMA_CHAT_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${OLLAMA_API_KEY}`,
    },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new Error(`Ollama API error ${response.status}: ${text}`);
  }

  const data = await response.json();
  return data?.message?.content ?? "";
}

module.exports = { chat };
